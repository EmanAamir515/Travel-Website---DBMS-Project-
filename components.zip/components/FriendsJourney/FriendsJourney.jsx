import React, { useEffect, useState } from 'react';
import axios from 'axios';
import './FriendsJourney.css';
import { FiHeart, FiMessageSquare, FiSend, FiArrowLeft } from 'react-icons/fi';

const Journey = ({ onBack, currentUserID }) => {
  const [travelHistory, setTravelHistory] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [filteredHistory, setFilteredHistory] = useState([]);
  const [searchMessage, setSearchMessage] = useState('');
  const [isSearching, setIsSearching] = useState(false);
  const [likedHistories, setLikedHistories] = useState(new Set());
  const [commentInputs, setCommentInputs] = useState({});
  const [comments, setComments] = useState({});

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        // First fetch all travel history
        const historyResponse = await axios.get('http://localhost:3001/travel-history');
        
        if (historyResponse.data?.success) {
     

          const friendsJourneys = historyResponse.data.travels;
          if (friendsJourneys.length === 0) {
            setSearchMessage("No friends' journeys available");
          } else {
            // Fetch media and likes for each journey
            const journeysWithDetails = await Promise.all(
              friendsJourneys.map(async journey => {
                try {
                  const [mediaResponse, commentsResponse] = await Promise.all([
                    axios.get(`http://localhost:3001/travel-media/${journey.history_id}`),
                    axios.get(`http://localhost:3001/comments/${journey.history_id}`)
                  ]);

                  return {
                    ...journey,
                    media: mediaResponse.data?.map(m => ({
                      ...m,
                      url: m.media_url.startsWith('http') ? m.media_url : `http://localhost:3001${m.media_url}`
                    })) || [],
                    comments: commentsResponse.data || []
                  };
                } catch (error) {
                  console.error('Error loading journey details:', error);
                  return {
                    ...journey,
                    media: [],
                    comments: []
                  };
                }
              })
            );

            setTravelHistory(journeysWithDetails);
            
            // Load user's liked journeys
            try {
              const likesResponse = await axios.get(`http://localhost:3001/likes/user/${currentUserID}`);
              if (likesResponse.data?.success) {
                setLikedHistories(new Set(likesResponse.data.likes.map(like => like.history_id)));
              }
            } catch (likesError) {
              console.error('Error loading likes:', likesError);
            }
          }
        } else {
          setSearchMessage("No travel history available");
        }
      } catch (err) {
        console.error('Error loading data:', err);
        setSearchMessage("Failed to load journeys");
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [currentUserID]);

  // const handleSearch = async () => {
  //   if (!searchTerm.trim()) {
  //     setIsSearching(false);
  //     setSearchMessage('');
  //     return;
  //   }

  //   try {
  //     setLoading(true);
  //     setIsSearching(true);
  //     const response = await axios.get(`http://localhost:3001/travel-history-by-country?area_name=${searchTerm}`);
      
  //     if (response.data?.success) {
  //       // Filter out current user's journeys from search results
  //       // const filteredResults = response.data.travels.filter(
  //       //   journey => journey.userID !== currentUserID
  //       // );
  //       const filteredResults = response.data.travels;

  //       if (filteredResults.length > 0) {
  //         setFilteredHistory(filteredResults);
  //         setSearchMessage('');
  //       } else {
  //         setFilteredHistory([]);
  //         setSearchMessage('No matching journeys found');
  //       }
  //     } else {
  //       setFilteredHistory([]);
  //       setSearchMessage('No results found');
  //     }
  //   } catch (err) {
  //     console.error('Search error:', err);
  //     setSearchMessage('Failed to search');
  //   } finally {
  //     setLoading(false);
  //   }
  // };

 // Update the handleSearch function
const handleSearch = async () => {
  if (!searchTerm.trim()) {
    setIsSearching(false);
    setSearchMessage('');
    return;
  }

  try {
    setLoading(true);
    setIsSearching(true);
    const response = await axios.get(
      `http://localhost:3001/travel-history-by-country?area_name=${searchTerm}`
    );
    
    if (response.data?.success) {
      const filteredResults = response.data.travels;

      if (filteredResults.length > 0) {
        // Fetch media and comments for each search result
        const journeysWithDetails = await Promise.all(
          filteredResults.map(async journey => {
            try {
              const [mediaResponse, commentsResponse] = await Promise.all([
                axios.get(`http://localhost:3001/travel-media/${journey.history_id}`),
                axios.get(`http://localhost:3001/comments/${journey.history_id}`)
              ]);

              return {
                ...journey,
                media: mediaResponse.data?.map(m => ({
                  ...m,
                  url: m.media_url.startsWith('http') ? m.media_url : `http://localhost:3001${m.media_url}`
                })) || [],
                comments: commentsResponse.data || []
              };
            } catch (error) {
              console.error('Error loading journey details:', error);
              return {
                ...journey,
                media: [],
                comments: []
              };
            }
          })
        );

        setFilteredHistory(journeysWithDetails);
        setSearchMessage('');
      } else {
        setFilteredHistory([]);
        setSearchMessage('No matching journeys found');
      }
    } else {
      setFilteredHistory([]);
      setSearchMessage('No results found');
    }
  } catch (err) {
    console.error('Search error:', err);
    setSearchMessage('Failed to search');
  } finally {
    setLoading(false);
  }
};

  const handleLike = async (history_id) => {
    try {
      const response = await axios.post(
        'http://localhost:3001/likes',
        { userID: currentUserID, history_id }
      );

      if (response.data.success) {
        setLikedHistories(prev => new Set(prev).add(history_id));
      }
    } catch (err) {
      console.error('Like error:', err);
    }
  };

  const handleAddComment = async (history_id) => {
    const commentText = commentInputs[history_id]?.trim();
    if (!commentText) return;

    try {
      const response = await axios.post(
        'http://localhost:3001/comments',
        {
          userID: currentUserID,
          history_id,
          comment_text: commentText
        }
      );

      if (response.data.success) {
        // Refresh comments for this journey
        const commentsResponse = await axios.get(
          `http://localhost:3001/comments/${history_id}`
        );
        
        setComments(prev => ({
          ...prev,
          [history_id]: commentsResponse.data || []
        }));
        
        // Clear input
        setCommentInputs(prev => ({
          ...prev,
          [history_id]: ''
        }));
      }
    } catch (err) {
      console.error('Comment error:', err);
    }
  };

  const resultsToDisplay = isSearching ? filteredHistory : travelHistory;

  return (
    <div className="journey-container">
      <button onClick={onBack} className="back-button">
        <FiArrowLeft /> Back to Dashboard
      </button>
      <h2>ALL Travel Journeys</h2>

      <div className="search-bar">
        <input
          type="text"
          placeholder="Search by area Name..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
          className="search-input"
        />
        <button onClick={handleSearch} className="search-button">
          Search
        </button>
      </div>

      {loading ? (
        <div className="loading-spinner"></div>
      ) : (
        <div className="travel-grid">
          {resultsToDisplay.length > 0 ? (
            resultsToDisplay.map((item) => (
              <div key={item.history_id} className="travel-card">
                <div className="travel-header">
                  <h3>{item.title}</h3>
                <span className="traveler">
                  by {item.accountName} {item.history_type === 'shared' ? '(Shared Trip)' : ''}
                </span>               
                 </div>

                {item.media?.length > 0 && (
                  <div className="travel-media">
                    {item.media.map((media, idx) => (
                      <img
                        key={idx}
                        src={media.url}
                        alt={`${item.title} - ${idx + 1}`}
                        onError={(e) => {
                          e.target.src = '/placeholder-image.jpg';
                          e.target.alt = 'Image not available';
                        }}
                      />
                    ))}
                  </div>
                )}

                <div className="travel-details">
                  <p><strong>Location:</strong> {item.location_name}</p>
                  <p><strong>Dates:</strong> {new Date(item.startDate).toLocaleDateString()} - {new Date(item.end_date).toLocaleDateString()}</p>
                  {item.descriptionOfArea && (
                    <p className="description">{item.descriptionOfArea}</p>
                  )}
                  {item.experiences && (
                    <p className="experiences"><strong>Experiences:</strong> {item.experiences}</p>
                  )}
                </div>

                <div className="travel-actions">
                  <button
                    onClick={() => handleLike(item.history_id)}
                    className={`like-btn ${likedHistories.has(item.history_id) ? 'liked' : ''}`}
                  >
                    <FiHeart /> {likedHistories.has(item.history_id) ? 'Liked' : 'Like'}
                  </button>

                  <div className="comment-section">
                    <div className="comment-list">
                      {(item.comments || comments[item.history_id] || []).map((comment, i) => (
                        <div key={i} className="comment-item">
                          <strong>{comment.accountName}:</strong> {comment.comment_text}
                        </div>
                      ))}
                    </div>

                    <div className="comment-input">
                      <input
                        type="text"
                        placeholder="Add a comment..."
                        value={commentInputs[item.history_id] || ''}
                        onChange={(e) => setCommentInputs(prev => ({
                          ...prev,
                          [item.history_id]: e.target.value
                        }))}
                      />
                      <button onClick={() => handleAddComment(item.history_id)}>
                        <FiSend />
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            ))
          ) : (
            <div className="no-journeys-message">
              <p>{searchMessage || "No journeys to display"}</p>
              {!isSearching && (
                <button onClick={() => window.location.reload()}>Refresh</button>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default Journey;
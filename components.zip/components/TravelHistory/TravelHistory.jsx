import React, { useEffect, useState } from 'react';
import './TravelHistory.css';
import { FiArrowLeft, FiPlus, FiX, FiChevronDown, FiChevronUp, FiUploadCloud, FiEdit2, FiTrash2 } from 'react-icons/fi';

const History = ({ user, onBack }) => {
  const [trips, setTrips] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [expandedTrip, setExpandedTrip] = useState(null);
  const [comments, setComments] = useState({});
  const [likes, setLikes] = useState({});
  const [showForm, setShowForm] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [filteredTrips, setFilteredTrips] = useState([]);
  const [isSearching, setIsSearching] = useState(false);
  const [searchMessage, setSearchMessage] = useState('');
  const [media, setMedia] = useState({});
  const [files, setFiles] = useState([]);
  const [previewUrls, setPreviewUrls] = useState([]);
  const [editingTrip, setEditingTrip] = useState(null);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [tripToDelete, setTripToDelete] = useState(null);
const [sharedDetails, setSharedDetails] = useState({});
  const [formData, setFormData] = useState({
    title: '',
    country: '',
    location: '',
    startDate: '',
    endDate: '',
    description: '',
    experiences: ''
  });

  const fetchMedia = async (history_id) => {
    try {
      const response = await fetch(`http://localhost:3001/travel-media/${history_id}`);
      if (!response.ok) throw new Error('Failed to fetch media');
      return await response.json();
    } catch (err) {
      console.error('Error fetching media:', err);
      return [];
    }
  };

  useEffect(() => {
    const fetchData = async () => {
      try {
        const historyResponse = await fetch(`http://localhost:3001/travel-history/${user.id}`);
        if (!historyResponse.ok) throw new Error('Failed to fetch history');
        const historyData = await historyResponse.json();
        
        const tripsArray = Array.isArray(historyData.travels) ? historyData.travels : 
                         (historyData.recordset || []);
        
        setTrips(tripsArray);

        const mediaData = {};
        await Promise.all(tripsArray.map(async (trip) => {
          mediaData[trip.history_id] = await fetchMedia(trip.history_id);
        }));
        setMedia(mediaData);

        const commentsData = {};
        const likesData = {};
        
        await Promise.all(tripsArray.map(async (trip) => {
          const commentsResponse = await fetch(`http://localhost:3001/comments/${trip.history_id}`);
          if (commentsResponse.ok) {
            commentsData[trip.history_id] = await commentsResponse.json();
          }
          
          const likesResponse = await fetch(`http://localhost:3001/likes/${trip.history_id}`);
          if (likesResponse.ok) {
            likesData[trip.history_id] = await likesResponse.json();
          }
        }));

        setComments(commentsData);
        setLikes(likesData);

      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    const fetchSharedDetails = async () => {
  try {
    const response = await fetch(`http://localhost:3001/shared-history-details/${user.id}`);
    if (response.ok) {
      const data = await response.json();
      // Create a mapping of history_id to shared details
      const sharedMap = {};
      data.sharedHistories.forEach(history => {
        sharedMap[history.history_id] = {
          accountName: history.other_accountName,
          connectionStatus: history.Connections_status
        };
      });
      setSharedDetails(sharedMap);
    }
  } catch (err) {
    console.error('Error fetching shared details:', err);
  }
};
  fetchSharedDetails();
    fetchData();
  }, [user.id]);


  

  const handleFileUpload = (e) => {
    const newFiles = Array.from(e.target.files).slice(0, 5);
    setFiles(newFiles);
    
    const urls = newFiles.map(file => URL.createObjectURL(file));
    setPreviewUrls(urls);
  };

  const handleEdit = (trip) => {
    setEditingTrip(trip);
    setFormData({
      title: trip.title,
      country: trip.area_name,
      location: trip.location_name,
      startDate: trip.startDate.split('T')[0],
      endDate: trip.end_date.split('T')[0],
      description: trip.descriptionOfArea || '',
      experiences: trip.experiences || ''
    });
    setShowForm(true);
  };

  const handleDelete = (trip) => {
    setTripToDelete(trip);
    setShowDeleteConfirm(true);
  };

const confirmDelete = async () => {
  if (!tripToDelete) return;
  
  try {
    const response = await fetch(`http://localhost:3001/travel-history/${tripToDelete.history_id}`, {
      method: 'DELETE',
      credentials: 'include',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        userID: user.id // Make sure to send the userID
      })
    });

    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(errorData.message || 'Failed to delete trip');
    }

    // Refresh the trips list
    const historyResponse = await fetch(`http://localhost:3001/travel-history/${user.id}`);
    if (!historyResponse.ok) throw new Error('Failed to refresh history');
    
    const newData = await historyResponse.json();
    setTrips(newData.travels || newData.recordset || []);
    
    setShowDeleteConfirm(false);
    setTripToDelete(null);
  } catch (err) {
    setError(err.message);
    setShowDeleteConfirm(false);
  }
};

  const cancelDelete = () => {
    setShowDeleteConfirm(false);
    setTripToDelete(null);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!formData.title || !formData.country || !formData.location || !formData.startDate || !formData.endDate) {
      setError('Please fill all required fields');
      return;
    }

    if (new Date(formData.startDate) > new Date(formData.endDate)) {
      setError('End date must be after start date');
      return;
    }

    const maxSize = 5 * 1024 * 1024;
    const oversizedFiles = files.filter(file => file.size > maxSize);
    if (oversizedFiles.length > 0) {
      setError(`File ${oversizedFiles[0].name} exceeds 5MB limit`);
      return;
    }

    setError('');
    setLoading(true);

    try {
      const formPayload = new FormData();
      formPayload.append('userID', user.id);
      formPayload.append('title', formData.title);
      formPayload.append('area_name', formData.country);
      formPayload.append('location_name', formData.location);
      formPayload.append('description', formData.description || '');
      formPayload.append('experiences', formData.experiences || '');
      formPayload.append('startDate', formData.startDate);
      formPayload.append('endDate', formData.endDate);

      files.forEach((file) => {
        formPayload.append('images', file);
      });

      const url = editingTrip 
        ? `http://localhost:3001/travel-history/${editingTrip.history_id}`
        : 'http://localhost:3001/travel-history';
      
      const method = editingTrip ? 'PUT' : 'POST';

      const response = await fetch(url, {
        method,
        body: formPayload,
        credentials: 'include'
      });
      
      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.message || 'Failed to add travel history');
      }

      const [historyResponse, mediaResponse] = await Promise.all([
        fetch(`http://localhost:3001/travel-history/${user.id}`),
        fetch(`http://localhost:3001/travel-media/${user.id}`)
      ]);

      if (!historyResponse.ok) throw new Error('Failed to refresh history');

      const newData = await historyResponse.json();
      setTrips(newData.travels || newData.recordset || []);

      setShowForm(false);
      setFormData({
        title: '',
        country: '',
        location: '',
        startDate: '',
        endDate: '',
        description: '',
        experiences: ''
      });
      setFiles([]);
      setPreviewUrls([]);
      setEditingTrip(null);

    } catch (err) {
      console.error('Submission error:', err);
      setError(err.message || 'An error occurred during submission');
    } finally {
      setLoading(false);
    }
  };

  const handleSearch = async () => {
    if (!searchTerm.trim()) {
      setFilteredTrips([]);
      setIsSearching(false);
      setSearchMessage('');
      return;
    }

    setIsSearching(true);
    setError('');

    try {
      const url = `http://localhost:3001/search-travel-history?area_name=${encodeURIComponent(searchTerm)}&userID=${user.id}`;
      const response = await fetch(url);
      
      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.message || `HTTP error! status: ${response.status}`);
      }

      const data = await response.json();
      
      if (data.travels && data.travels.length > 0) {
        setFilteredTrips(data.travels);
        setSearchMessage('');
        
        const mediaData = {};
        await Promise.all(data.travels.map(async (trip) => {
          mediaData[trip.history_id] = await fetchMedia(trip.history_id);
        }));
        setMedia(prev => ({...prev, ...mediaData}));
      } else {
        setFilteredTrips([]);
        setSearchMessage('No matching trips found');
      }
      
    } catch (err) {
      console.error('Search failed:', err);
      setError(err.message || 'Search failed');
      setFilteredTrips([]);
      setSearchMessage('Search failed - please try again');
    } finally {
      setIsSearching(false);
    }
  };

  const formatSqlDate = (dateString) => {
    if (!dateString) return 'No date';
    
    const date = new Date(dateString);
    
    if (isNaN(date.getTime())) {
      const parts = dateString.split('T')[0].split('-');
      if (parts.length === 3) {
        return `${parts[2]}/${parts[1]}/${parts[0]}`;
      }
      return dateString;
    }
    
    return date.toLocaleDateString('en-GB');
  };

  const toggleExpand = (tripId) => {
    setExpandedTrip(expandedTrip === tripId ? null : tripId);
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  return (
    <div className="history-container">
      <div className="header-with-back">
        <button onClick={onBack} className="back-button">
          <FiArrowLeft /> Back to Dashboard
        </button>
        <h2>My Travel History</h2>
      </div>
      
      {!showForm ? (
        <>
          <button onClick={() => setShowForm(true)} className="add-history-button">
            <FiPlus /> Add New Travel History
          </button>
          
          <div className="search-bar">
            <input
              type="text"
              placeholder="Search by Area name..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="search-input"
            />
            <button onClick={handleSearch} className="search-button">
              Search
            </button>
          </div>

          {loading ? (
            <div className="loading-spinner"></div>
          ) : error ? (
            <p className="error-message">{error}</p>
          ) : (
            <>
              {searchMessage && <p className="search-message">{searchMessage}</p>}
              <div className="trips-list">
                {(filteredTrips.length > 0 ? filteredTrips : trips).map((trip) => (
                  <div key={trip.history_id} className={`trip-card ${expandedTrip === trip.history_id ? 'expanded' : ''}`}>
                    <div className="trip-header" onClick={() => toggleExpand(trip.history_id)}>
                    <div className="trip-title">
                      {trip.title} 
                      {trip.history_type === 'shared' && (
                        <span className="shared-badge"> 
                          (Shared with {sharedDetails[trip.history_id]?.accountName || 'another user'})
                        </span>
                      )}
                    </div>
                      <div className="trip-dates">
                        {formatSqlDate(trip.startDate)} - {formatSqlDate(trip.end_date)}
                      </div>
                      <div className="trip-country">{trip.area_name}</div>
                      {expandedTrip === trip.history_id ? <FiChevronUp /> : <FiChevronDown />}
                    </div>
                    
                    {expandedTrip === trip.history_id && (
                      <div className="trip-details">
                        <div className="trip-description">
                          <h4>Description:</h4>
                          <p>{trip.descriptionOfArea || 'No description provided'}</p>
                        </div>
                        <div className="trip-experiences">
                          <h4>Experiences:</h4>
                          <p>{trip.experiences || 'No experiences shared'}</p>
                        </div>
                        
                        {media[trip.history_id] && media[trip.history_id].length > 0 && (
                          <div className="trip-media">
                            <h4>Photos:</h4>
                            <div className="media-grid">
                              {media[trip.history_id].map((item, index) => (
                                <div key={index} className="media-item">
                                  <img 
                                    src={`http://localhost:3001/uploads/${item.media_url}`} 
                                    alt={`Travel media ${index}`}
                                    className="trip-image"
                                  />
                                </div>
                              ))}
                            </div>
                          </div>
                        )}
                        
                        <div className="trip-interactions">
                          <div className="likes-section">
                            <span className="likes-count">{likes[trip.history_id]?.length || 0} Likes</span>
                            {likes[trip.history_id]?.length > 0 && (
                              <div className="likes-list">
                                Liked by: {likes[trip.history_id].map(like => like.accountName).join(', ')}
                              </div>
                            )}
                          </div>
                          <div className="comments-section">
                            <h4>Comments:</h4>
                            {comments[trip.history_id]?.length > 0 ? (
                              <div className="comments-list">
                                {comments[trip.history_id].map((comment, index) => (
                                  <div key={index} className="comment">
                                    <strong>{comment.accountName || 'Anonymous'}:</strong> {comment.comment_text}
                                  </div>
                                ))}
                              </div>
                            ) : (
                              <p>No comments yet</p>
                            )}
                          </div>
                          
                          {/* Edit and Delete buttons */}
                          <div className="trip-actions">
                            <button 
                              className="edit-button"
                              onClick={(e) => {
                                e.stopPropagation();
                                handleEdit(trip);
                              }}
                            >
                              <FiEdit2 /> Edit
                            </button>
                            <button 
                              className="delete-button"
                              onClick={(e) => {
                                e.stopPropagation();
                                handleDelete(trip);
                              }}
                            >
                              <FiTrash2 /> Delete
                            </button>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </>
          )}
        </>
      ) : (
        <div className="history-form-container">
          <div className="form-header">
            <h3>{editingTrip ? 'Edit Travel History' : 'Add New Travel History'}</h3>
            <button 
              onClick={() => {
                setShowForm(false);
                setEditingTrip(null);
                setFormData({
                  title: '',
                  country: '',
                  location: '',
                  startDate: '',
                  endDate: '',
                  description: '',
                  experiences: ''
                });
              }} 
              className="close-button"
            >
              <FiX />
            </button>
          </div>
          <form onSubmit={handleSubmit}>
            {error && <p className="form-error">{error}</p>}
            <div className="form-group">
              <label>Title*</label>
              <input
                type="text"
                name="title"
                value={formData.title}
                onChange={handleInputChange}
                required
              />
            </div>

            <div className="form-group">
              <label>Area Name*</label>
              <input
                type="text"
                name="country"
                value={formData.country}
                onChange={handleInputChange}
                required
              />
            </div>
            <div className="form-group">
              <label>Location (City/Region)*</label>
              <input
                type="text"
                name="location"
                value={formData.location}
                onChange={handleInputChange}
                required
              />
            </div>

            <div className="form-group">
              <label>Start Date*</label>
              <input
                type="date"
                name="startDate"
                value={formData.startDate}
                onChange={handleInputChange}
                required
              />
            </div>

            <div className="form-group">
              <label>End Date*</label>
              <input
                type="date"
                name="endDate"
                value={formData.endDate}
                onChange={handleInputChange}
                required
              />
            </div>

            <div className="form-group">
              <label>Description</label>
              <textarea
                name="description"
                value={formData.description}
                onChange={handleInputChange}
                rows="3"
              />
            </div>

            <div className="form-group">
              <label>Experiences</label>
              <textarea
                name="experiences"
                value={formData.experiences}
                onChange={handleInputChange}
                rows="3"
              />
            </div>

            <div className="form-group">
              <label>Upload Images (Max 5, 5MB each)</label>
              <div className="file-upload-container">
                <label className="file-upload-label">
                  <FiUploadCloud className="upload-icon" />
                  <span>Choose Files</span>
                  <input 
                    type="file" 
                    onChange={handleFileUpload}
                    multiple
                    accept="image/*"
                    className="file-upload-input"
                  />
                </label>
                {files.length > 0 && (
                  <div className="file-list">
                    {files.map((file, index) => (
                      <div key={index} className="file-item">
                        {file.name} ({Math.round(file.size / 1024)} KB)
                      </div>
                    ))}
                  </div>
                )}
              </div>
              
              {previewUrls.length > 0 && (
                <div className="image-previews">
                  {previewUrls.map((url, index) => (
                    <img 
                      key={index} 
                      src={url} 
                      alt={`Preview ${index}`} 
                      className="image-preview"
                      onLoad={() => URL.revokeObjectURL(url)}
                    />
                  ))}
                </div>
              )}
            </div>
            
            <div className="form-actions">
              <button type="button" onClick={() => {
                setShowForm(false);
                setEditingTrip(null);
              }} className="cancel-button">
                Cancel
              </button>
              <button type="submit" className="submit-button" disabled={loading}>
                {loading ? 'Submitting...' : 'Submit'}
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Delete confirmation dialog */}
      {showDeleteConfirm && (
        <div className="confirmation-dialog">
          <div className="confirmation-content">
            <h3>Confirm Deletion</h3>
            <p>Are you sure you want to delete this trip: "{tripToDelete?.title}"?</p>
            <p>This action cannot be undone.</p>
            <div className="confirmation-buttons">
              <button onClick={cancelDelete} className="cancel-button">
                Cancel
              </button>
              <button onClick={confirmDelete} className="delete-button">
                Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default History;